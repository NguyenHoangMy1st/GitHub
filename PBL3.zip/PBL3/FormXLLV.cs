﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Pbl3_new_.BLL;
using Pbl3_new_.DTO;

namespace Pbl3_new_
{
    //public partial class Temp
    //{
    //    public string MaNV { get; set; }
    //    public int soLan { get; set; }
    //}
    public partial class FormXLLV : Form
    {
        PBL3NETEntities1 db =new PBL3NETEntities1();
        public static DateTime GetFistDayInMonth(int year, int month)
        {
            DateTime aDateTime = new DateTime(year, month, 1);
            return aDateTime;
        }
        // Trả về ngày cuối cùng của tháng.
        public static DateTime GetLastDayInMonth(int year, int month)
        {
            DateTime aDateTime = new DateTime(year, month, 1);

            // Cộng thêm 1 tháng và trừ đi một ngày.
            DateTime retDateTime = aDateTime.AddMonths(1).AddDays(-1);
            return retDateTime;
        }
        public void view()
        {
            DateTime dn = DateTime.Today;
            DateTime date1=GetFistDayInMonth(dn.Year, dn.Month);
            DateTime date2=GetLastDayInMonth(dn.Year, dn.Month);
            string d1 = date1.Year.ToString()+'-'+ date1.Month.ToString()+'-'+date1.Day.ToString();
            string d2 = date2.Year.ToString() + '-' + date2.Month.ToString() + '-' + date2.Day.ToString();
            Console.WriteLine(d2 + " " + d1);
            dgvPhaChe.DataSource = BLLQLNV.Instance.GetLichLamViecPhaChe();
            for (int i = 0; i <= dgvPhaChe.Columns.Count - 1; i++)
            {
                dgvPhaChe.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
            dgvPhucVu.DataSource = BLLQLNV.Instance.GetLichLamViecPhucVu();
            for (int i = 0; i <= dgvPhucVu.Columns.Count - 1; i++)
            {
                dgvPhucVu.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
        }
        public FormXLLV()
        {
           InitializeComponent();
           view();
        }
        public void Xoa()
        {
            DateTime dn = DateTime.Today;
            DateTime date1 = GetFistDayInMonth(dn.Year, dn.Month);
            DateTime date2 = GetLastDayInMonth(dn.Year, dn.Month);
            string d1 = date1.Year.ToString() + '-' + date1.Month.ToString() + '-' + date1.Day.ToString();
            string d2 = date2.Year.ToString() + '-' + date2.Month.ToString() + '-' + date2.Day.ToString();
            string s = string.Format("delete from LichLamViec where ngay between '{0}' and '{1}'", d1, d2);
            db.Database.ExecuteSqlCommand(s);


        }
        public List<NV> NVPhucVuKhongBanLich(DateTime date1, string buoi)
        {
            List<NV> data = new List<NV>();
            string d1 = date1.Year.ToString() + '-' + date1.Month.ToString() + '-' + date1.Day.ToString();
            string s=string.Format("select * from LichNghi where ngay='{0}' and buoi= '{1}'",d1, buoi);
            var d=db.LichNghi.SqlQuery(s).ToList();
            data = db.NV.Where(x => x.ID_ChucVu == 2).ToList();
            foreach (NV nv in data)
            {
                foreach(var i in d)
                {
                    if(i.MaNV==nv.MaNV)
                    {
                        data.Remove(nv);
                    }    
                }    
            }
            return data;
        }
        public List<NV> NVPhaCheKhongBanLich(DateTime date1, string buoi)
        {
            List<NV> data = new List<NV>();
            string d1 = date1.Year.ToString() + '-' + date1.Month.ToString() + '-' + date1.Day.ToString();
            string s = string.Format("select * from LichNghi where ngay='{0}' and buoi= '{1}'", d1, buoi);
            var d = db.LichNghi.SqlQuery(s).ToList();
            data = db.NV.Where(x => x.ID_ChucVu==1).ToList();
            Console.WriteLine("so nhanvien="+data.Count);
            foreach (NV nv in data.ToList())
            {
                foreach (var i in d)
                {
                    if (i.MaNV == nv.MaNV)
                    {
                        data.Remove(nv);
                    }
                }
            }
            return data;
        }
        public string MaNVCoSoCaLamMin(List<NV> nv,List<Temp> temps)
        {
            int min = 9999;
            string id_min = "";
            foreach(NV k in nv)
            {
                int nv_k = 9999;
                string id_k = "";
                foreach(Temp temp in temps)
                {
                    if (k.MaNV == temp.MaNV)
                    {
                        nv_k = temp.soLan;
                        //temp.soLan += 1;
                        id_k = temp.MaNV;
                    }    
                }
               
                if (nv_k < min)
                {
                    min = nv_k;
                    id_min = id_k;
              
                }    
            }    
            foreach(Temp t in temps)
            {
                if(t.MaNV == id_min)
                {
                    t.soLan = t.soLan + 1;
                }    
            }    
            foreach(var t in temps)
            {
                Console.WriteLine("manv: "+ t.MaNV+ "solan: "+t.soLan);
            }    
            Console.WriteLine("id min:"+ id_min);
            return id_min;
            //using(var db =new QLNVPBL3())
            //{
            //    int min = 9999;
            //    string id_min = "";
            //    foreach (NV i in nv)
            //    {
            //        if (i.SoNgayDiLam < min)
            //        {
            //            min = i.SoNgayDiLam;
            //            id_min = i.MaNV;
            //        }
            //    }
            //    var nhanvien = db.NV.Where(x => x.MaNV == id_min).FirstOrDefault();
            //    nhanvien.SoNgayDiLam = nhanvien.SoNgayDiLam + 1;
            //    db.Entry(nhanvien).State = System.Data.Entity.EntityState.Modified;
            //    db.SaveChanges();
            //    return id_min;
            //} 
            
           
        }
        private void buttonxeplich_Click(object sender, EventArgs e)
        {
            BLLQLNV.Instance.ResetLuong();
            /*
            DateTime dn = DateTime.Today;
            Xoa();
            LichLamViec lichLamViec = new LichLamViec()
            {
                ngay = GetFistDayInMonth(dn.Year, dn.Month),
                buoi = "sang",
                PhaChe1 = "4",
                PhaChe2 = "2",
                PhucVu1 = "1",
                PhucVu2 = "5",
            };
            db.LichLamViec.Add(lichLamViec);
            db.SaveChanges();
            view();

            */
            Xoa();
            var nhanVien= db.NV.ToList();
            List<Temp> temps = new List<Temp>();
            foreach(NV i in nhanVien)
            {
                Temp t= new Temp();
                t.MaNV = i.MaNV.ToString();
                t.soLan = 0;
                temps.Add(t);
            }    
            DateTime dn = DateTime.Today;
            DateTime date1 = GetFistDayInMonth(dn.Year, dn.Month);
            DateTime date2 = GetLastDayInMonth(dn.Year, dn.Month);
            for (int i=date1.Day;i<=date2.Day;i++)
            {
                DateTime ngay = new DateTime(date1.Year, date1.Month, i);

                LichLamViec lichLamViecSang = new LichLamViec()
                {
                    ngay = ngay,
                    buoi = "sang",
                    PhucVu1 = MaNVCoSoCaLamMin(NVPhucVuKhongBanLich(ngay, "sang"),temps),
                    PhucVu2= MaNVCoSoCaLamMin(NVPhucVuKhongBanLich(ngay,"sang"),temps),
                    PhaChe1= MaNVCoSoCaLamMin(NVPhaCheKhongBanLich(ngay,"sang"),temps),
                    PhaChe2 = MaNVCoSoCaLamMin(NVPhaCheKhongBanLich(ngay, "sang"),temps),
                    DiemDanhPV1 = false,
                    DiemDanhPV2 = false,
                    DiemDanhPC1 = false,
                    DiemDanhPC2 = false,
                };
                db.LichLamViec.Add(lichLamViecSang);
                db.SaveChanges();

                LichLamViec lichLamViecChieu = new LichLamViec()
                {
                    ngay = ngay,
                    buoi = "chieu",
                    PhucVu1 = MaNVCoSoCaLamMin(NVPhucVuKhongBanLich(ngay, "chieu"),temps),
                    PhucVu2 = MaNVCoSoCaLamMin(NVPhucVuKhongBanLich(ngay, "chieu"), temps),
                    PhaChe1 = MaNVCoSoCaLamMin(NVPhaCheKhongBanLich(ngay, "chieu"), temps),
                    PhaChe2 = MaNVCoSoCaLamMin(NVPhaCheKhongBanLich(ngay, "chieu"), temps),
                    DiemDanhPV1 = false,
                    DiemDanhPV2 = false,
                    DiemDanhPC1 = false,
                    DiemDanhPC2 = false,
                };
                db.LichLamViec.Add(lichLamViecChieu);

                db.SaveChanges();

                LichLamViec lichLamViecToi = new LichLamViec()
                {
                    ngay = ngay,
                    buoi = "toi",
                    PhucVu1 = MaNVCoSoCaLamMin(NVPhucVuKhongBanLich(ngay, "toi"), temps),
                    PhucVu2 = MaNVCoSoCaLamMin(NVPhucVuKhongBanLich(ngay, "toi"), temps),
                    PhaChe1 = MaNVCoSoCaLamMin(NVPhaCheKhongBanLich(ngay, "toi"), temps),
                    PhaChe2 = MaNVCoSoCaLamMin(NVPhaCheKhongBanLich(ngay, "toi"), temps),
                    DiemDanhPV1 = false,
                    DiemDanhPV2 = false,
                    DiemDanhPC1 = false,
                    DiemDanhPC2 = false,
                };
                db.LichLamViec.Add(lichLamViecToi);

                db.SaveChanges();
                view();
            }
           
        }
    }
}