﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pbl3_new_.BLL;

namespace Pbl3_new_
{
    public partial class FormUpdateTTCN_admin_ : Form
    {
        public delegate void MyDel(string MaNV);
        public MyDel d { get; set; }
        NV nv = new NV();
        public FormUpdateTTCN_admin_(NV n)
        {
            InitializeComponent();
            nv = n;
            GUI();
        }

        public void GUI()
        {
            txtMaQL.Enabled = false;
            txtMaQL.Text = nv.MaNV;
            txtName.Text = nv.HoVaTen;
            txtCMND.Text = nv.CMND;
            txtEmail.Text = nv.Email;
            txtQueQuan.Text = nv.QueQuan;
            txtSDT.Text = nv.SDT;
            dateTimePicker1.Value = nv.NgaySinh;
            if (nv.GioiTinh == true)
            {
                radioButtonNam.Enabled = true;
            }
            else
            {
                radioButtonNu.Enabled = true;
            }
        }

        private void buttonupdate_Click(object sender, EventArgs e)
        {
            NV nv = new NV()
            {
                MaNV = txtMaQL.Text,
                CMND = txtCMND.Text,
                HoVaTen = txtName.Text,
                NgaySinh = dateTimePicker1.Value,
                Email = txtEmail.Text,
                GioiTinh = Convert.ToBoolean(radioButtonNam.Checked),
                SDT = txtSDT.Text,
                QueQuan = txtQueQuan.Text,

            };
           BLLQLNV.Instance.UpdateTTCNAdmin(nv);
           d(nv.MaNV);
           this.Close();
        }

        private void buttonthoat_Click(object sender, EventArgs e)
        {
            this.Dispose();
            
        }
    }
}
