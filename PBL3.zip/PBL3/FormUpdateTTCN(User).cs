﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pbl3_new_.BLL;
using Pbl3_new_.DTO;

namespace Pbl3_new_
{
    public partial class FormUpdateTTCN_User_ : Form
    {
        public delegate void MyDel(string MaNV);
        public MyDel d { get; set; }
        NV nv = new NV();
        public FormUpdateTTCN_User_(NV n)
        {
            InitializeComponent();
            cbbCV.Items.AddRange(BLLQLNV.Instance.GetCbbChucVu().ToArray());
            nv = n;
            GUI();
        }

        public void GUI()
        {
            txtMaQL.Enabled = false;
            txtMaQL.Text = nv.MaNV;
            txtName.Text = nv.HoVaTen;
            txtCMND.Text = nv.CMND;
            txtEmail.Text = nv.Email;
            txtQueQuan.Text = nv.QueQuan;
            txtSDT.Text = nv.SDT;
            dateTimePicker1.Value = nv.NgaySinh;
            txtTKNH.Text = nv.TK_NganHang;
            if (nv.GioiTinh == true)
            {
                radioButtonNam.Enabled = true;
            }
            else
            {
                radioButtonNu.Enabled = true;
            }
            foreach (CBBItem i in cbbCV.Items)
            {
                if (i.Value == nv.ID_ChucVu)
                {
                    cbbCV.SelectedItem = i;
                }
            }
        }

        private void buttonupdate_Click(object sender, EventArgs e)
        {
            NV n = new NV()
            {
                MaNV = txtMaQL.Text,
                CMND = txtCMND.Text,
                HoVaTen = txtName.Text,
                NgaySinh = dateTimePicker1.Value,
                Email = txtEmail.Text,
                GioiTinh = Convert.ToBoolean(radioButtonNam.Checked),
                SDT = txtSDT.Text,
                QueQuan = txtQueQuan.Text,
                TK_NganHang = txtTKNH.Text,
                ID_ChucVu = Convert.ToInt32(((CBBItem)cbbCV.SelectedItem).Value),
            };
            BLLQLNV.Instance.UpdateTTCNUser(n);
            d(nv.MaNV);
            this.Close();
        }

        private void buttonthoat_Click(object sender, EventArgs e)
        {
            this.Dispose();

        }

 
    }
}
