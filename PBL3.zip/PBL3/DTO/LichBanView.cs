﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pbl3_new_.DTO
{
    internal class LichBanView
    {
        public Nullable<System.DateTime> ngay { get; set; }
        public string buoi { get; set; }
    }
}
