﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pbl3_new_.DTO
{
    internal class Luong_NV_View
    {
        public string MaNV { get; set; }
        public string HoVaTen { get; set; }
        public string NameCV { get; set; }
        public double LuongTheoH { get; set; }
        public double TongLuong { get; set; }
}
}
