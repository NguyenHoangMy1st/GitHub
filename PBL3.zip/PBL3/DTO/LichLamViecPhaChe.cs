﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pbl3_new_.DTO
{
    internal class LichLamViecPhaChe
    {
        public Nullable<System.DateTime> ngay { get; set; }
        public string buoi { get; set; }
        public string PhaChe1 { get; set; }
        public string PhaChe2 { get; set; }
    }
}
