﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pbl3_new_.DTO
{
    public class NV_View
    {
        public string MaNV { get; set; }
        public string HoVaTen { get; set; }
        public bool GioiTinh { get; set; }
        public System.DateTime NgaySinh { get; set; }
        public string SDT { get; set; }
        public string Email { get; set; }
        public string CMND { get; set; }
        public string QueQuan { get; set; }
        public string TK_NganHang { get; set; }
        public string NameCV { get; set; }
    }
}
