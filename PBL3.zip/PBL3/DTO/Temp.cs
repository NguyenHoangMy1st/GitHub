﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pbl3_new_.DTO
{
    public class Temp
    {
        public string MaNV { get; set; }
        public int soLan { get; set; }
        public Temp()
        {
        }
    }
}
