﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pbl3_new_.DTO
{
    internal class LichLamViecPhucVu
    {
        public Nullable<System.DateTime> ngay { get; set; }
        public string buoi { get; set; }
        public string PhucVu1 { get; set; }
        public string PhucVu2 { get; set; }

    }
}
