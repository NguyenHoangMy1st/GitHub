﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pbl3_new_.BLL;
using Pbl3_new_.DTO;
using System.IO;
using OfficeOpenXml;
using Excel = Microsoft.Office.Interop.Excel;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace Pbl3_new_
{
    public partial class FormTinhLuong : Form
    {
        public FormTinhLuong()
        {
            InitializeComponent();
            cbbChucVu.Items.AddRange(BLLQLNV.Instance.GetCbbChucVu().ToArray());
        }

        private void cbBchucvu_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ID_Chucvu = ((CBBItem)cbbChucVu.SelectedItem).Value;
            txtTienLuong.Text = BLLQLNV.Instance.getLuongCoBanByIDChucVu(ID_Chucvu).ToString();
            dataGridView1.DataSource = BLLQLNV.Instance.GetLuongNVViewByIDChucVu(ID_Chucvu);
            for (int i = 0; i <= dataGridView1.Columns.Count - 1; i++)
            {
                dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
        }

        private void buttonsave_Click(object sender, EventArgs e)
        {
            int ID_Chucvu = ((CBBItem)cbbChucVu.SelectedItem).Value;
            BLLQLNV.Instance.SetLuongCoBan(ID_Chucvu, Convert.ToDouble(txtTienLuong.Text));
            dataGridView1.DataSource = BLLQLNV.Instance.GetLuongNVViewByIDChucVu(ID_Chucvu);
            for (int i = 0; i <= dataGridView1.Columns.Count - 1; i++)
            {
                dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
            
        }
        private void ExportExcel(string path)
        {
            Excel.Application app = new Excel.Application();
            app.Application.Workbooks.Add(Type.Missing);
            for (int i = 0; i < dataGridView1.Columns.Count; i++)
            {
                app.Cells[1, i + 1] = dataGridView1.Columns[i].HeaderText;
            }
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for (int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    app.Cells[i + 2, j + 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                }
            }
            app.Columns.AutoFit();
            app.ActiveWorkbook.SaveCopyAs(path);
            app.ActiveWorkbook.Saved = true;
        }

        private void buttonExcel_Click(object sender, EventArgs e)
        {
            SaveFileDialog sf = new SaveFileDialog();
            sf.Filter = "Excel(.xlsx)| *.xlsx";
            if (sf.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    ExportExcel(sf.FileName);
                    MessageBox.Show("Bạn đã xuất file thành công!");
                }
                catch (Exception ex)
                { MessageBox.Show("Bạn đã xuất file không thành công!\n" + ex.Message); }
            }
        }

        private void buttonPDF_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                SaveFileDialog save = new SaveFileDialog();
                save.Filter = "PDF (*.pdf)|*.pdf";
                bool ErrorMessage = false;
                if (save.ShowDialog() == DialogResult.OK)
                {
                    if (File.Exists(save.FileName))
                    {
                        try
                        {
                            File.Delete(save.FileName);
                        }
                        catch (Exception ex)
                        {

                            ErrorMessage = true;

                            MessageBox.Show("Không thể ghi dữ liệu" + ex.Message);
                        }
                    }
                    if (!ErrorMessage)
                    {
                        try
                        {

                            PdfPTable pTable = new PdfPTable(dataGridView1.Columns.Count);

                            pTable.DefaultCell.Padding = 2;

                            pTable.WidthPercentage = 100;

                            pTable.HorizontalAlignment = Element.ALIGN_LEFT;

                            foreach (DataGridViewColumn col in dataGridView1.Columns)
                            {

                                PdfPCell pCell = new PdfPCell(new Phrase(col.HeaderText));

                                pTable.AddCell(pCell);
                            }
                            foreach (DataGridViewRow viewRow in dataGridView1.Rows)
                            {
                                foreach (DataGridViewCell dcell in viewRow.Cells)
                                {
                                    pTable.AddCell(dcell.Value.ToString());
                                }
                            }
                            using (FileStream fileStream = new FileStream(save.FileName, FileMode.Create))
                            {
                                Document document = new Document(PageSize.A4, 8f, 16f, 16f, 8f);

                                PdfWriter.GetInstance(document, fileStream);

                                document.Open();

                                document.Add(pTable);

                                document.Close();

                                fileStream.Close();
                            }
                            MessageBox.Show("Bạn đã xuất flie thành công", "info");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Bạn đã xuất file  không thành công" + ex.Message);
                        }
                    }

                }

            }

            else

            {

                MessageBox.Show("Không tìm thấy bản ghi", "Info");

            }
        }

        
    }
}
