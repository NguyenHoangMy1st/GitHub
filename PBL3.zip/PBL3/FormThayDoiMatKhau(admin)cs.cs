﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pbl3_new_.BLL;

namespace Pbl3_new_
{
    public partial class FormThayDoiMatKhau_admin_cs : Form
    {
        NV nv = new NV();
        public FormThayDoiMatKhau_admin_cs(NV n)
        {
            InitializeComponent();
            nv = n;
        }


        private void buttonthoat_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void buttonsave_Click(object sender, EventArgs e)
        {
            if(txtMkCu.Text != nv.MatKhau)
            {
                MessageBox.Show("Mat khau cu sai");
            }
            else if(txtMkMoi.Text != txtNhapLaiMk.Text)
            {
                MessageBox.Show("Mat khau moi khong trung nhau");
            }
            else
            {
                MessageBox.Show("Doi mat khau thanh cong");
                nv.MatKhau = txtMkMoi.Text;
                BLLQLNV.Instance.UpdateMK(nv);
                this.Close();
            }
        }
    }
}
