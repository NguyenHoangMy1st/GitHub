﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pbl3_new_.BLL;

namespace Pbl3_new_
{
    public partial class FormCapnhatMKNV : Form
    {
        NV nv = new NV();
        public FormCapnhatMKNV(string MaNV)
        {
            InitializeComponent();
            nv = BLLQLNV.Instance.GetNVByMaNV(MaNV);
            txtMaNV.Enabled = false;
            txtMaNV.Text = nv.MaNV;
        }

        private void buttonsave_Click(object sender, EventArgs e)
        {
            if (txtMkMoi.Text != txtNhapLaiMk.Text)
            {
                MessageBox.Show("Mat khau moi khong trung nhau");
            }
            else
            {
                MessageBox.Show("Doi mat khau thanh cong");
                nv.MatKhau = txtMkMoi.Text;
                BLLQLNV.Instance.UpdateMK(nv);
                this.Close();
            }
        }

        private void buttonthoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
