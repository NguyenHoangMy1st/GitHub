﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pbl3_new_.BLL;

namespace Pbl3_new_
{
    public partial class FormXemLich : Form
    {
        NV nv  = new NV();
        public FormXemLich(NV n)
        {
            InitializeComponent();
            nv = n;
            dataGridView1.DataSource = BLLQLNV.Instance.GetLichLamViecNVByMaNV(nv.MaNV);
            for(int i = 0; i <= dataGridView1.Columns.Count - 1; i++)
            {
                dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
            
        }
    }
}
