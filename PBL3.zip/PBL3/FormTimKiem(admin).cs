﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pbl3_new_.BLL;

namespace Pbl3_new_
{
    public partial class FormTimKiem_admin_ : Form
    {
        public FormTimKiem_admin_()
        {
            InitializeComponent();
        }

        private void buttonsearch_Click(object sender, EventArgs e)
        {
            foreach (NV n in BLLQLNV.Instance.GetALLNV())
            {
                if (txtSearch.Text == n.MaNV.ToString() && rdbtnMaNV.Checked == true)
                {
                    dataGridView1.DataSource = BLLQLNV.Instance.SearchNVByMaNV(txtSearch.Text);
                    for (int i = 0; i <= dataGridView1.Columns.Count - 1; i++)
                    {
                        dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    }
                }
                if (txtSearch.Text == n.HoVaTen.ToString() && rdbtnName.Checked == true)
                {
                    dataGridView1.DataSource = BLLQLNV.Instance.SearchNVByNameNV(txtSearch.Text);
                    for (int i = 0; i <= dataGridView1.Columns.Count - 1; i++)
                    {
                        dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    }
                }
                if (txtSearch.Text == n.CMND.ToString() && rdbtnCMND.Checked == true)
                {
                    dataGridView1.DataSource = BLLQLNV.Instance.SearchNVByCMND(txtSearch.Text);
                    for (int i = 0; i <= dataGridView1.Columns.Count - 1; i++)
                    {
                        dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    }
                }
            }
        }
    }
}
