﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pbl3_new_.BLL;

namespace Pbl3_new_
{
    public partial class FormThayDoiMatKhau_user_ : Form
    {
        NV nv = new NV();
        public FormThayDoiMatKhau_user_(NV n)
        {
            InitializeComponent();
            nv = n;
            txtMaNV.Text = nv.MaNV;
            txtMaNV.Enabled = false;
        }

        private void buttonthoat_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void buttonsave_Click(object sender, EventArgs e)
        {
            if(txtMKCu.Text != nv.MatKhau)
            {
                MessageBox.Show("sai mật khẩu cũ");
            }
            else if(txtNhapLaiMK.Text != txtMKMoi.Text)
            {
                MessageBox.Show("Nhập lại mật khẩu mới sai");
            }
            else
            {
                MessageBox.Show("Bạn đã đổi mật khẩu thành công");
                nv.MatKhau = txtMKMoi.Text;
                BLLQLNV.Instance.UpdateMK(nv);
                this.Close();
            }
        }
    }
}
