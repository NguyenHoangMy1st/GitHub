﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pbl3_new_.BLL;
using Pbl3_new_.DTO;

namespace Pbl3_new_
{
    public partial class FormAddTTNV : Form
    {
        public delegate void MyDel(int MaNV);
        public MyDel d { get; set; }
        public string MaNhanVien { get; set; }

        public FormAddTTNV(string MaNV)
        {
            InitializeComponent();
            MaNhanVien = MaNV;
            cbbTK.Items.AddRange(BLLQLNV.Instance.GetCbbLoaiTK().ToArray());
            cbbCV.Items.AddRange(BLLQLNV.Instance.GetCbbChucVu().ToArray());
            GUI();
        }
        public void GUI()
        {
            NV n = BLLQLNV.Instance.GetNVByMaNV(MaNhanVien);
            if (MaNhanVien != "")
            {
                txtMaNV.Enabled = false;
                txtMaNV.Text = n.MaNV;
                txtName.Text = n.HoVaTen;
                int ID_ChucVu = Convert.ToInt32(n.ID_ChucVu);
                foreach (CBBItem i in cbbCV.Items)
                {
                    if (i.Value == n.ID_ChucVu)
                    {
                        cbbCV.SelectedItem = i;
                    }
                }
                txtCMND.Text = n.CMND;
                dateTimePicker1.Value = n.NgaySinh;
                if (n.GioiTinh == true)
                {
                    radioButtonNam.Checked = true;
                }
                else
                {
                    radioButtonNu.Checked = true;
                }
                txtTK.Visible = false;
                txtTKNH.Text = n.TK_NganHang;
                txtPass.Visible = false;
                txtEmail.Text = n.Email;
                txtQQ.Text = n.QueQuan;
                txtSDT.Text = n.SDT;
                txtCMND.Text = n.CMND;
                cbbTK.Visible = false;
                lbTK.Visible = false;
                lbTKuser.Visible = false;
                lbPass.Visible = false;

            }
            else
            {
                txtMaNV.Enabled = false;
                txtMaNV.Text = Convert.ToString(BLLQLNV.Instance.GetNewMaNV());
            }
            if (MaNhanVien != "")
            {
                btnUpdate.Visible = true;
                buttonAdd.Visible = false;
                label1.Text = "Cập nhật nhân viên";
            }
            else
            {
                btnUpdate.Visible = false;
                buttonAdd.Visible = true;
            }



        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            NV nv = new NV()
            {
                MaNV = txtMaNV.Text,
                HoVaTen = txtName.Text,
                ID_ChucVu = ((CBBItem)cbbCV.SelectedItem).Value,
                NgaySinh = dateTimePicker1.Value,
                ID_LoaiTK = ((CBBItem)cbbTK.SelectedItem).Value,
                GioiTinh = Convert.ToBoolean(radioButtonNam.Checked),
                TaiKhoan = txtTK.Text,
                MatKhau = txtPass.Text,
                CMND = txtCMND.Text,
                QueQuan = txtQQ.Text,
                SDT = txtSDT.Text,
                TK_NganHang = txtTKNH.Text,
                Email = txtEmail.Text,

            };
            BLLQLNV.Instance.Execute(nv);
            d(2);
            this.Close();
        }

        private void buttonthoat_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            NV nv = new NV()
            {
                MaNV = txtMaNV.Text,
                HoVaTen = txtName.Text,
                ID_ChucVu = ((CBBItem)cbbCV.SelectedItem).Value,
                NgaySinh = dateTimePicker1.Value,
                GioiTinh = Convert.ToBoolean(radioButtonNam.Checked),
                CMND = txtCMND.Text,
                QueQuan = txtQQ.Text,
                SDT = txtSDT.Text,
                TK_NganHang = txtTKNH.Text,
                Email = txtEmail.Text,

            };
            BLLQLNV.Instance.Execute(nv);
            d(2);
            this.Close();

        }

        private void cbbTK_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cbbTK.SelectedItem.ToString() == "admin")
            {
                cbbCV.Enabled = false;
            }
        }

        private void cbbCV_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cbbCV.SelectedItem.ToString() == "phuc vu")
            {
                cbbTK.Text = "user";
            }
            if (cbbCV.SelectedItem.ToString() == "phache")
            {
                cbbTK.Text = "user";
            }
        }
    }
}
