﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using OfficeOpenXml;
using Excel = Microsoft.Office.Interop.Excel;
using Pbl3_new_.BLL;
using iTextSharp.text;
using iTextSharp.text.pdf;
namespace Pbl3_new_
{
    public partial class FormTTNV : Form
    {
        public FormTTNV()
        {
            InitializeComponent();
            Show(2);
        }
        public void Show(int ID_TK)
        {
            dataGridView1.DataSource = BLLQLNV.Instance.GetNVViewByIDLoaiTK(ID_TK);
            for (int i = 0; i <= dataGridView1.Columns.Count - 1; i++)
            {
                dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
        }



        private void butAdd_Click(object sender, EventArgs e)
        {
            FormAddTTNV f = new FormAddTTNV("");
            f.Show();
            f.d = new FormAddTTNV.MyDel(Show);
        }

        private void butUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                string MaNV = dataGridView1.SelectedRows[0].Cells["MaNV"].Value.ToString();
                FormAddTTNV f = new FormAddTTNV(MaNV);
                f.Show();
                f.d = new FormAddTTNV.MyDel(Show);
            }

        }

        private void butDel_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                string MaNV = dataGridView1.SelectedRows[0].Cells["MaNV"].Value.ToString();
                BLLQLNV.Instance.DelNV(MaNV);
                Show(2);
            }
        }

        private void buttonreset_Click(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count == 1)
            {
                string MaNV = dataGridView1.SelectedRows[0].Cells["MaNV"].Value.ToString();
                FormCapnhatMKNV f = new FormCapnhatMKNV(MaNV);
                f.Show();
            }
        }
        private void ExportExcel(string path)
        {
            Excel.Application app = new Excel.Application();
            app.Application.Workbooks.Add(Type.Missing);
            for(int i = 0; i < dataGridView1.Columns.Count; i++)
            {
                app.Cells[1, i + 1] = dataGridView1.Columns[i].HeaderText;
            }
            for(int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                for(int j = 0; j < dataGridView1.Columns.Count; j++)
                {
                    app.Cells[i+2, j+ 1] = dataGridView1.Rows[i].Cells[j].Value.ToString();
                }    
            }
            app.Columns.AutoFit();
            app.ActiveWorkbook.SaveCopyAs(path);
            app.ActiveWorkbook.Saved = true;
        }

        private void buttonExcel_Click(object sender, EventArgs e)
        {
            SaveFileDialog sf = new SaveFileDialog();
            sf.Filter = "Excel(.xlsx)| *.xlsx";
            if(sf.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    ExportExcel(sf.FileName);
                    MessageBox.Show("Bạn đã xuất file thành công!");
                }
                catch(Exception ex)
                { MessageBox.Show("Bạn đã xuất file không thành công!\n" + ex.Message); }
            }    
        }

        private void buttonPDF_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                SaveFileDialog save = new SaveFileDialog();
                save.Filter = "PDF (*.pdf)|*.pdf";
                bool ErrorMessage = false;
                if (save.ShowDialog() == DialogResult.OK)
                {
                    if (File.Exists(save.FileName))
                    {
                        try
                        {
                            File.Delete(save.FileName);
                        }
                        catch (Exception ex)
                        {

                            ErrorMessage = true;

                            MessageBox.Show("Không thể ghi dữ liệu" + ex.Message);
                        }
                    }
                    if (!ErrorMessage)
                    {
                        try
                        {

                            PdfPTable pTable = new PdfPTable(dataGridView1.Columns.Count);

                            pTable.DefaultCell.Padding = 2;

                            pTable.WidthPercentage = 100;

                            pTable.HorizontalAlignment = Element.ALIGN_LEFT;

                            foreach (DataGridViewColumn col in dataGridView1.Columns)
                            {

                                PdfPCell pCell = new PdfPCell(new Phrase(col.HeaderText));

                                pTable.AddCell(pCell);
                            }
                            foreach (DataGridViewRow viewRow in dataGridView1.Rows)
                            {
                                foreach (DataGridViewCell dcell in viewRow.Cells)
                                {
                                    pTable.AddCell(dcell.Value.ToString());
                                }
                            }
                            using (FileStream fileStream = new FileStream(save.FileName, FileMode.Create))
                            {
                                Document document = new Document(PageSize.A4, 8f, 16f, 16f, 8f);

                                PdfWriter.GetInstance(document, fileStream);

                                document.Open();

                                document.Add(pTable);

                                document.Close();

                                fileStream.Close();
                            }
                            MessageBox.Show("Bạn đã xuất file thành công", "info");
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Bạn đã xuất flie không thành công" + ex.Message);
                        }
                    }

                }

            }

            else

            {

                MessageBox.Show("Không tìm thấy bản ghi", "Info");

            }
        }
    }

}

