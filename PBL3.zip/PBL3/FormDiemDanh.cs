﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pbl3_new_.BLL;
using Pbl3_new_.DTO;

namespace Pbl3_new_
{
    public partial class FormDiemDanh : Form
    {
        NV nv = new NV();
   

        public FormDiemDanh(NV n)
        {
            InitializeComponent();
            label3.Text = DateTime.Now.ToString();
            nv = n;
            dataGridView1.DataSource = BLLQLNV.Instance.GetDiemDanhNVByMaNV(nv.MaNV);
            dataGridView1.Columns[0].Visible = false;
            for (int i = 0; i <= dataGridView1.Columns.Count - 1; i++)
            {
                dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
        }


        private void timer1_Tick(object sender, EventArgs e)
        {
            label3.Text = DateTime.Now.ToString("dd/ MM /yyy");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count == 1)
            {
                string ngay = dataGridView1.SelectedRows[0].Cells["ngay"].Value.ToString();
                int ID = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["id"].Value);
                DialogResult dlr = MessageBox.Show("Xác nhận điểm danh ngày " + ngay + "\nLưu ý: Nếu xác thực sai sự thật, bạn phải chịu hoàn toàn trách nhiệm với xác thực này", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dlr == DialogResult.Yes)
                {
                    BLLQLNV.Instance.DiemDanh(nv.MaNV, ID);
                } 
            }
        }
    }
}
