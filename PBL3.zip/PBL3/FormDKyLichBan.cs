﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pbl3_new_.BLL;
using Pbl3_new_.DTO;

namespace Pbl3_new_
{
    public partial class FormDKyLichBan : Form
    {
        int ID_lich;
        NV nv = new NV();
        PBL3NETEntities1 db =new PBL3NETEntities1();
        public FormDKyLichBan(NV n)
        {
            InitializeComponent();
            foreach(string i in BLLQLNV.Instance.GetCbbCaLam().Distinct())
            {
                cbbCa.Items.Add(i);
            }
            nv = n;
            //dataGridView1.DataSource = BLLQLNV.Instance.GetAllLichBanByMaNV(nv.MaNV);
            //dataGridView1.DataSource = db.LichNghi.Where(x => x.MaNV == nv.MaNV).ToList();
            dataGridView1.DataSource = BLLQLNV.Instance.GetLichBanViewByMaNV(nv.MaNV);
            for (int i = 0; i <= dataGridView1.Columns.Count - 1; i++)
            {
                dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
        }

        private void btnXacNhan_Click(object sender, EventArgs e)
        {
            //DateTime day = dateTimePicker1.Value;

            //foreach(lich l in BLLQLNV.Instance.GetAllLich())
            //{
            //    if(l.ngaylamviec == day.Date)
            //    {
            //        ID_lich = l.id_lich;
            //    }
            //}
            //LichBan lb = new LichBan()
            //{
            //    Id_Ban = BLLQLNV.Instance.GetNewIDLichBan(),
            //    Id_Lich = ID_lich,
            //    MaNV = nv.MaNV
            //};
            //BLLQLNV.Instance.AddLichBan(lb);
            //dataGridView1.DataSource = BLLQLNV.Instance.GetAllLichBanByMaNV(nv.MaNV);

            DateTime day = dateTimePicker1.Value;
            string buoi= cbbCa.Text;
            LichNghi lichNghi = new LichNghi();
            lichNghi.buoi = buoi;
            lichNghi.MaNV = nv.MaNV;
            lichNghi.ngay = day;
            db.LichNghi.Add(lichNghi);
            db.SaveChanges();
            dataGridView1.DataSource=db.LichNghi.Where(x => x.MaNV == nv.MaNV).ToList();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count == 1)
            {
                int Id_LichBan = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["id"].Value);
                var item= db.LichNghi.SingleOrDefault(x=> x.id == Id_LichBan);
                db.LichNghi.Remove(item);
                db.SaveChanges();
            }
            //dataGridView1.DataSource = BLLQLNV.Instance.GetAllLichBanByMaNV(nv.MaNV);
            dataGridView1.DataSource = db.LichNghi.Where(x => x.MaNV == nv.MaNV).ToList();
        }
    }
}
