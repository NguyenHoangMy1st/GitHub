﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pbl3_new_.BLL;

namespace Pbl3_new_
{
    public partial class FormTTCN : Form
    {
        NV nv = new NV();
        public FormTTCN(NV n)
        {
            InitializeComponent();
            nv = n;
            GUI();
        }

        public void GUI()
        {
            txtMaQL.Enabled = false;
            txtMaQL.Text = nv.MaNV;
            txtName.Enabled = false;
            txtName.Text = nv.HoVaTen;
            txtCMND.Enabled = false;
            txtCMND.Text = nv.CMND;
            txtEmail.Enabled = false;
            txtEmail.Text = nv.Email;
            txtQueQuan.Enabled = false;
            txtQueQuan.Text = nv.QueQuan;
            txtSDT.Enabled = false;
            txtSDT.Text = nv.SDT;
            dateTimePicker1.Enabled = false;
            dateTimePicker1.Value = nv.NgaySinh;
            if(nv.GioiTinh == true)
            {
                radioButtonNam.Checked = true;
            }
            else
            {
                radioButtonNu.Checked = true;
            }
        }

        private void buttonupdate_Click(object sender, EventArgs e)
        {
            FormUpdateTTCN_admin_ f = new FormUpdateTTCN_admin_(nv);
            f.d = new FormUpdateTTCN_admin_.MyDel(Show);
            f.ShowDialog();
        }

        public void Show(String MaNV)
        {
            NV n = BLLQLNV.Instance.GetNVByMaNV(MaNV);
            if(n == null)
            {
                txtMaQL.Text = nv.MaNV;
                txtName.Text = nv.HoVaTen;
                txtCMND.Text = nv.CMND;
                txtEmail.Text = nv.Email;
                txtQueQuan.Text = nv.QueQuan;
                txtSDT.Text = nv.SDT;
                dateTimePicker1.Value = nv.NgaySinh;
                if (nv.GioiTinh == true)
                {
                    radioButtonNam.Checked = true;
                }
                else
                {
                    radioButtonNu.Checked = true;
                }
            }
        }

        private void buttonthaydoimk_Click(object sender, EventArgs e)
        {
            FormThayDoiMatKhau_admin_cs f = new FormThayDoiMatKhau_admin_cs(nv);
            f.ShowDialog();
        }
    }
}
