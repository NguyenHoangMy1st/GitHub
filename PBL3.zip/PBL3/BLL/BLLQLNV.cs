﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pbl3_new_.DTO;

namespace Pbl3_new_.BLL
{
    internal class BLLQLNV
    {
        double luongCB;
        PBL3NETEntities1 db = new PBL3NETEntities1();
        private static BLLQLNV _Instance;
        public static BLLQLNV Instance
        {
            get
            {
                if (_Instance == null)
                {
                    _Instance = new BLLQLNV();
                }
                return _Instance;
            }
            private set { }
        }
        private BLLQLNV()
        {

        }

        public List<NV> GetALLNV()
        {
            List<NV> data = new List<NV>();
            foreach (NV nv in db.NV)
            {
                data.Add(nv);
            }
            return data;
        }

        public List<int> GetAllMaNV()
        {
            List<int> data = new List<int>();
            foreach (NV nv in db.NV)
            {
                data.Add(Convert.ToInt32(nv.MaNV));
            }
            return data;
        }

        public int GetNewMaNV()
        {
            int MaNV_new = 1;
            foreach (int MaNV in GetAllMaNV())
            {
                if (MaNV_new == MaNV)
                {
                    MaNV_new++;
                }
            }
            return MaNV_new;
        }

        public NV GetNVByMaNV(int MaNV)
        {
            NV n = db.NV.Find(MaNV);
            return n;
        }

        public List<string> GetCbbCaLam()
        {
            List<string> data = new List<string>();
            foreach (LichLamViec l in db.LichLamViec)
            {
               data.Add(l.buoi);
            }
            return data;
        }

        public List<CBBItem> GetCbbChucVu()
        {

            List<CBBItem> data = new List<CBBItem>();
            foreach (ChucVu i in db.ChucVu)
            {
                data.Add(new CBBItem
                {
                    Value = i.ID_ChucVu,
                    Text = i.NameCV
                });
            }
            return data;
        }

        public List<CBBItem> GetCbbLoaiTK()
        {
            List<CBBItem> data = new List<CBBItem>();
            foreach (TaiKhoan i in db.TaiKhoan)
            {
                data.Add(new CBBItem
                {
                    Value = i.ID_LoaiTK,
                    Text = i.LoaiTK
                });
            }
            return data;
        }

        public List<NV> GetNVByChucVu(int ID_ChucVu)
        {
            List<NV> data = new List<NV>();
            if (ID_ChucVu == 0)
            {
                foreach (NV nv in db.NV)
                {
                    data.Add(nv);
                }
            }
            else
            {
                foreach (NV nv in db.NV)
                {
                    if (nv.ID_ChucVu == ID_ChucVu)
                    {
                        data.Add(nv);
                    }
                }
            }
            return data;
        }

        public List<NV> GetNVByLoaiTK(int ID_LoaiTK)
        {
            List<NV> data = new List<NV>();
            if (ID_LoaiTK == 0)
            {
                foreach (NV nv in db.NV)
                {
                    data.Add(nv);
                }
            }
            else
            {
                foreach (NV nv in db.NV)
                {
                    if (nv.ID_LoaiTK == ID_LoaiTK)
                    {
                        data.Add(nv);
                    }
                }
            }
            return data;
        }

        public List<NV_View> GetNVViewByIDLoaiTK(int ID_LoaiTK)
        {
            List<NV_View> data = new List<NV_View>();
            foreach (NV n in GetNVByLoaiTK(ID_LoaiTK))
            {
                string ChucVu = "";
                foreach (ChucVu j in db.ChucVu)
                {
                    if (j.ID_ChucVu == n.ID_ChucVu)
                    {
                        ChucVu = j.NameCV;
                        break;
                    }
                }
                data.Add(new NV_View
                {
                    MaNV = n.MaNV,
                    HoVaTen = n.HoVaTen,
                    GioiTinh = n.GioiTinh,
                    NgaySinh = n.NgaySinh,
                    SDT = n.SDT,
                    Email = n.Email,
                    CMND = n.CMND,
                    QueQuan = n.QueQuan,
                    TK_NganHang = n.TK_NganHang,
                    NameCV = ChucVu
                });
            }
            return data;
        }

        public List<Luong_NV_View> GetLuongNVViewByIDChucVu(int ID_Chucvu)
        {
            List<Luong_NV_View> data = new List<Luong_NV_View>();
            foreach (NV n in GetNVByChucVu(ID_Chucvu))
            {
                string ChucVu = "";

                foreach (ChucVu j in db.ChucVu)
                {
                    if (j.ID_ChucVu == n.ID_ChucVu)
                    {
                        ChucVu = j.NameCV;
                        luongCB = j.LuongCoBan;
                        break;
                    }
                }
                data.Add(new Luong_NV_View
                {
                    MaNV = n.MaNV,
                    HoVaTen = n.HoVaTen,
                    NameCV = ChucVu,
                    LuongTheoH = luongCB,
                    TongLuong = luongCB * n.SoNgayDiLam * 5,
                });
                n.Luong = luongCB * n.SoNgayDiLam * 5;
            }
            return data;
        }

        public List<Luong_NV_View> GetLuongNVViewByMaNV(string MaNV)
        {
            List<Luong_NV_View> data = new List<Luong_NV_View>();
            foreach (NV n in db.NV)
            {
                string ChucVu = "";

                foreach (ChucVu j in db.ChucVu)
                {
                    if (j.ID_ChucVu == n.ID_ChucVu)
                    {
                        ChucVu = j.NameCV;
                        luongCB = j.LuongCoBan;
                        break;
                    }
                }
                if(n.MaNV == MaNV)
                {
                    data.Add(new Luong_NV_View
                    {
                        MaNV = n.MaNV,
                        HoVaTen = n.HoVaTen,
                        NameCV = ChucVu,
                        LuongTheoH = luongCB,
                        TongLuong = luongCB * n.SoNgayDiLam * 5,
                    });
                }
            }
            return data;
        }

        public List<LichLamViecPhaChe> GetLichLamViecPhaChe()
        {
            List<LichLamViecPhaChe> data = new List<LichLamViecPhaChe> ();
            NV PC1;
            NV PC2;
            foreach (LichLamViec l in db.LichLamViec)
            {
                PC1 = db.NV.Find(l.PhaChe1);
                PC2 = db.NV.Find(l.PhaChe2);
                data.Add(new LichLamViecPhaChe
                {
                    ngay = l.ngay,
                    buoi = l.buoi,
                    PhaChe1 = PC1.HoVaTen,
                    PhaChe2 = PC2.HoVaTen,
                });
            }
            return data;
        }

        public List<LichLamViecPhucVu> GetLichLamViecPhucVu()
        {
            List<LichLamViecPhucVu> data = new List<LichLamViecPhucVu>();
            NV PV1;
            NV PV2;
            foreach (LichLamViec l in db.LichLamViec)
            {
                PV1 = db.NV.Find(l.PhucVu1);
                PV2 = db.NV.Find(l.PhucVu2);
                data.Add(new LichLamViecPhucVu
                {
                    ngay = l.ngay,
                    buoi = l.buoi,
                    PhucVu1 = PV1.HoVaTen,
                    PhucVu2 = PV2.HoVaTen,
                });
            }
            return data;
        }

        public NV GetNVByMaNV(string MaNV)
        {
            return db.NV.Find(MaNV);
        }

        public bool Check(string MaNV)
        {
            // true - add, false - update
            bool add = true;
            if (MaNV != "")
            {
                foreach (NV n in db.NV)
                {
                    if (n.MaNV == MaNV)
                        add = false;
                }
            }
            return add;
        }

        public void Execute(NV n)
        {
            
            if (Check(n.MaNV))
            {
                 db.NV.Add(n);   
            }
            else
            {
                NV nv = db.NV.Find(n.MaNV);
                nv.HoVaTen = n.HoVaTen;
                nv.GioiTinh = n.GioiTinh;
                nv.QueQuan = n.QueQuan;
                nv.NgaySinh = n.NgaySinh;
                nv.CMND = n.CMND;
                nv.SDT = n.SDT;
                nv.Email = n.Email;
                nv.ChucVu = n.ChucVu;
            }
            db.SaveChanges();
        }

        public string GetNameCVByIDChucVu(int ID_Chucvu)
        {
            string NameCV = "";
            foreach(ChucVu cv in db.ChucVu)
            {
                if(cv.ID_ChucVu == ID_Chucvu)
                {
                    NameCV = cv.NameCV;
                }
            }
            return NameCV;
        }

        public List<LichLamViecNV> GetLichLamViecNVByMaNV(string MaNV)
        {
            List<LichLamViecNV> data = new List<LichLamViecNV> ();
            foreach(LichLamViec l in db.LichLamViec)
            {
                if(l.PhaChe1.ToString() == MaNV || l.PhaChe2.ToString() == MaNV || l.PhucVu1.ToString() == MaNV || l.PhucVu2.ToString() == MaNV)
                {
                    data.Add(new LichLamViecNV
                    {
                        ngay = l.ngay,
                        buoi = l.buoi,
                    });
                }
            }
            return data;
        }

        public List<DiemDanhView> GetDiemDanhNVByMaNV(string MaNV)
        {
            List<DiemDanhView> data = new List<DiemDanhView>();
            foreach (LichLamViec l in db.LichLamViec)
            {
                if (l.PhaChe1.ToString() == MaNV)
                {
                    data.Add(new DiemDanhView
                    {
                        id = l.id,
                        ngay = l.ngay,
                        buoi = l.buoi,
                        DiemDanh = Convert.ToBoolean(l.DiemDanhPC1),
                    });
                }
                if (l.PhaChe2.ToString() == MaNV)
                {
                    data.Add(new DiemDanhView
                    {
                        id = l.id,
                        ngay = l.ngay,
                        buoi = l.buoi,
                        DiemDanh = Convert.ToBoolean(l.DiemDanhPC2),
                    });
                }
                if (l.PhucVu1.ToString() == MaNV)
                {
                    data.Add(new DiemDanhView
                    {
                        id = l.id,
                        ngay = l.ngay,
                        buoi = l.buoi,
                        DiemDanh = Convert.ToBoolean(l.DiemDanhPV1),
                    });
                }
                if (l.PhucVu2.ToString() == MaNV)
                {
                    data.Add(new DiemDanhView
                    {
                        id = l.id,
                        ngay = l.ngay,
                        buoi = l.buoi,
                        DiemDanh = Convert.ToBoolean(l.DiemDanhPV2),
                    });
                }



            }
            return data;
        }

        public void DiemDanh(string MaNV, int ID)
        {
            NV nv = db.NV.Find(MaNV);
            
            foreach(LichLamViec llv in db.LichLamViec)
            {
                if(ID == llv.id)
                {
                    if(MaNV.ToString() == llv.PhaChe1.ToString() && llv.DiemDanhPC1 == false)
                    {
                        nv.SoNgayDiLam++;
                        llv.DiemDanhPC1 = true;
                    }
                    if (MaNV.ToString() == llv.PhaChe2.ToString() && llv.DiemDanhPC2 == false)
                    {
                        nv.SoNgayDiLam++;
                        llv.DiemDanhPC2 = true;
                    }
                    if (MaNV.ToString() == llv.PhucVu1.ToString() && llv.DiemDanhPV1 == false)
                    {
                        nv.SoNgayDiLam++;
                        llv.DiemDanhPV1 = true;
                    }
                    if (MaNV.ToString() == llv.PhucVu2.ToString() && llv.DiemDanhPV2 == false)
                    {
                        nv.SoNgayDiLam++;
                        llv.DiemDanhPV2 = true;
                    }
                }
            }
            db.SaveChanges();
        }

        


        

        public void DelNV(string MaNV)
        {          
            
            NV n = db.NV.Find(MaNV);
            foreach(NV nv in db.NV)
            {
                if(nv.MaNV.ToString() == n.MaNV.ToString())
                {
                    foreach(LichLamViec llv in db.LichLamViec)
                    {
                        if(llv.PhaChe1.ToString() == nv.MaNV.ToString() || llv.PhaChe1 == null)
                        {
                            if(llv.PhaChe1 != null)
                            {
                                llv.PhaChe1 = null;
                            }
                           
                        }
                        if (llv.PhaChe2.ToString() == nv.MaNV.ToString() || llv.PhaChe2 == null)
                        {
                            if (llv.PhaChe2 != null)
                            {
                                llv.PhaChe2 = null;
                            }
                        }
                        if(llv.PhucVu1.ToString() == nv.MaNV.ToString() || llv.PhucVu1 == null)
                        {
                            if (llv.PhucVu1 != null)
                            {
                                llv.PhucVu1 = null;
                            }
                        }
                        if(llv.PhucVu2.ToString() == nv.MaNV.ToString() || llv.PhucVu2 == null)
                        {
                            if (llv.PhucVu2 != null)
                            {
                                llv.PhucVu2 = null;
                            }
                        }
                    }
                    foreach(LichNghi lb in db.LichNghi)
                    {
                        if(lb.MaNV.ToString() == nv.MaNV.ToString())
                        {
                            db.LichNghi.Remove(lb); 
                        }
                    }
                }
            }
            db.NV.Remove(n);
            
            db.SaveChanges();
        }

        public List<NV> SearchNVByMaNV(string txt)
        {
            List<NV> data = new List<NV>(); 
            foreach(NV n in db.NV)
            {
                if (txt == n.MaNV.ToString())
                {
                    data.Add(n);
                    return data;
                }
            }
            return data;
        }

        public List<NV> SearchNVByNameNV(string txt)
        {
            List<NV> data = new List<NV>();
            foreach (NV n in db.NV)
            {
                if (txt == n.HoVaTen.ToString())
                {
                    data.Add(n);
                }
            }
            return data;
        }

        public List<NV> SearchNVByCMND(string txt)
        {
            List<NV> data = new List<NV>();
            foreach (NV n in db.NV)
            {
                if (txt == n.CMND.ToString())
                {
                    data.Add(n);
                    return data;
                }
            }
            return data;
        }

        public void UpdateTTCNAdmin(NV n)
        {
                NV nv = db.NV.Find(n.MaNV);
                nv.HoVaTen = n.HoVaTen;
                nv.GioiTinh = n.GioiTinh;
                nv.QueQuan = n.QueQuan;
                nv.NgaySinh = n.NgaySinh;
                nv.CMND = n.CMND;
                nv.SDT = n.SDT;
                nv.Email = n.Email;
                nv.ChucVu = n.ChucVu;
            db.SaveChanges();
        }

        public List<LichBanView> GetLichBanViewByMaNV(string MA_NV)
        {
            List<LichBanView> data = new List<LichBanView>();
            foreach(LichNghi ln in db.LichNghi)
            {
                if(ln.MaNV == MA_NV)
                {
                    data.Add(new LichBanView
                    {
                        ngay = ln.ngay,
                        buoi = ln.buoi,
                    });
                }
                
            }
            return data;
        }

        public void UpdateTTCNUser(NV n)
        {
            NV nv = db.NV.Find(n.MaNV);
            nv.HoVaTen = n.HoVaTen;
            nv.GioiTinh = n.GioiTinh;
            nv.QueQuan = n.QueQuan;
            nv.NgaySinh = n.NgaySinh;
            nv.CMND = n.CMND;
            nv.SDT = n.SDT;
            nv.Email = n.Email;
            nv.ID_ChucVu = n.ID_ChucVu;
            nv.TK_NganHang = n.TK_NganHang;
            db.SaveChanges();
        }
        public void UpdateMK(NV n)
        {
            NV nv = db.NV.Find(n.MaNV);
            nv.MatKhau = n.MatKhau;
            db.SaveChanges();
        }

        public void ResetLuong()
        {
            foreach(NV n in db.NV)
            {
                NV nv = db.NV.Find(n.MaNV);
                nv.SoNgayDiLam = 0;
            }
            db.SaveChanges();
        }

        public double getLuongCoBanByIDChucVu(int ID_Chucvu)
        {
            double luongCoBan = 0;
            foreach(ChucVu cv in db.ChucVu)
            {
                if(cv.ID_ChucVu == ID_Chucvu)
                {
                    luongCoBan = cv.LuongCoBan;
                }
            }
            return luongCoBan;
        }

        public void SetLuongCoBan(int ID_Chucvu, double luong)
        {
            ChucVu cv = db.ChucVu.Find(ID_Chucvu);
            cv.LuongCoBan = luong;
            db.SaveChanges();
        }


 
        public List<NV> GetNVPhaChe()
        {
            List<NV> data = new List<NV>();
            foreach(NV n in db.NV)
            {
                if(n.ID_ChucVu == 1)
                {
                    data.Add(n);
                }
            }
            return data;
        }

        public List<NV> GetNVPhucVu()
        {
            List<NV> data = new List<NV>();
            foreach (NV n in db.NV)
            {
                if (n.ID_ChucVu == 2)
                {
                    data.Add(n);
                }
            }
            return data;
        }

    }
    }

 