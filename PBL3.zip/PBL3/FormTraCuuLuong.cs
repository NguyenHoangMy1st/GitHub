﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pbl3_new_.BLL;

namespace Pbl3_new_
{
    public partial class FormTraCuuLuong : Form
    {
        NV nv = new NV();
        public FormTraCuuLuong(NV n)
        {
            InitializeComponent();
            nv = n;
            GUI();
        }

        public void GUI()
        {
            txtMaNV.Enabled = false;
            txtName.Enabled = false;
            txtChucVu.Enabled = false;
            txtMaNV.Text = nv.MaNV;
            txtName.Text = nv.HoVaTen;
            txtChucVu.Text = BLLQLNV.Instance.GetNameCVByIDChucVu(Convert.ToInt32(nv.ID_ChucVu));

        }

        private void btnTraCuu_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = BLLQLNV.Instance.GetLuongNVViewByMaNV(nv.MaNV);
            for (int i = 0; i <= dataGridView1.Columns.Count - 1; i++)
            {
                dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
            }
        }
    }
}
