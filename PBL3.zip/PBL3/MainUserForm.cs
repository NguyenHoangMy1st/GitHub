﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FontAwesome.Sharp;


namespace Pbl3_new_
{
    public partial class MainUserForm : Form
    {
        private IconButton currentBtn;
        private Panel leftBorderBtn;
        private Form currentChildForm;
        NV nv = new NV();
        public MainUserForm(NV n)
        {
            InitializeComponent();
            customizedesign();
            nv = n;
        }

        private void iconcerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void iconmaximizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            iconrestaurar.Visible = true;
            iconmaximizar.Visible = false;
        }

        private void iconrestaurar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            iconrestaurar.Visible = false;
            iconmaximizar.Visible = true;
        }

        private void iconminimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString("HH:mm:ss");
            label2.Text = DateTime.Now.ToString("dd/ MM /yyy");
        }
        private void customizedesign()
        {
            panelQLLLV.Visible = false;
        }
        private void hidesubmenu()
        {
            if (panelQLLLV.Visible == true)
                panelQLLLV.Visible = false;
        }
        private void showsubmenu(Panel Submenu)
        {
            if (Submenu.Visible == false)
            {
                hidesubmenu();
                Submenu.Visible = true;
            }
            else
                Submenu.Visible = false;
        }

        private void ButQLLLV_Click(object sender, EventArgs e)
        {
            showsubmenu(panelQLLLV);
        }

        private void Butdangxuat_Click(object sender, EventArgs e)
        {
            DialogResult dlr = MessageBox.Show("Bạn muốn đăng xuất", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dlr == DialogResult.Yes)
            {
                FormDangNhap f = new FormDangNhap();
                f.Show();
                this.Close();
            }
        }



        private void ButQLTTCN_Click_1(object sender, EventArgs e)
        {
            FormQuanLiTTCN_User_ ttcn = new FormQuanLiTTCN_User_(nv);
            panelshow.Show();
            panelshow.Controls.Clear();
            ttcn.TopLevel = false;
            ttcn.Dock = DockStyle.Fill;
            panelshow.Controls.Add(ttcn);
            ttcn.Show();
        }

        private void Butslide_Click(object sender, EventArgs e)
        {
            if (panelMenu.Width == 358)
            {
                panelMenu.Width = 70;
                ButQLTTCN.Text = "";
                ButQLLLV.Text = "";
                ButXLLV.Text = "";
                ButDD.Text = "";
                ButDKLB.Text = "";
                ButTraCuuLuong.Text = "";
                ButTroGiup.Text = "";
                Butdangxuat.Text = "";

            }
            else
            {
                panelMenu.Width = 358;
                ButQLTTCN.Text = "Quản Lý Thông Tin Cá Nhân";
                ButQLTTCN.ForeColor = Color.White;
                ButQLLLV.Text = "Quản Lý Lịch Làm Việc";
                ButQLLLV.ForeColor = Color.White;
                ButXLLV.Text = "Xem Lịch Làm Việc";
                ButXLLV.ForeColor = Color.White;
                ButDD.Text = "Điểm Danh";
                ButDD.ForeColor = Color.White;
                ButDKLB.Text = "Đăng Kí Lịch Bận";
                ButDKLB.ForeColor = Color.White;
                ButTraCuuLuong.Text = "Tra Cứu Lương";
                ButTraCuuLuong.ForeColor = Color.White;
                ButTroGiup.Text = "Báo Lỗi";
                ButTroGiup.ForeColor = Color.White;
                Butdangxuat.Text = "Đăng xuất";
                Butdangxuat.ForeColor = Color.White;
            }


        }

        private void Buthome_Click(object sender, EventArgs e)
        {

            panelshow.Controls.Clear();
            panelshow.Show();
        }

        private void ButXLLV_Click(object sender, EventArgs e)
        {
            FormXemLich xl = new FormXemLich(nv);
            panelshow.Show();
            panelshow.Controls.Clear();
            xl.TopLevel = false;
            xl.Dock = DockStyle.Fill;
            panelshow.Controls.Add(xl);
            xl.Show();
        }

        private void ButDD_Click(object sender, EventArgs e)
        {
            FormDiemDanh dd = new FormDiemDanh(nv);
            panelshow.Show();
            panelshow.Controls.Clear();
            dd.TopLevel = false;
            dd.Dock = DockStyle.Fill;
            panelshow.Controls.Add(dd);
            dd.Show();
        }

        private void ButDKLB_Click(object sender, EventArgs e)
        {
            FormDKyLichBan lb = new FormDKyLichBan(nv);
            panelshow.Show();
            panelshow.Controls.Clear();
            lb.TopLevel = false;
            lb.Dock = DockStyle.Fill;
            panelshow.Controls.Add(lb);
            lb.Show();
        }

        private void ButTraCuuLuong_Click(object sender, EventArgs e)
        {
            FormTraCuuLuong tcl = new FormTraCuuLuong(nv);
            panelshow.Show();
            panelshow.Controls.Clear();
            tcl.TopLevel = false;
            tcl.Dock = DockStyle.Fill;
            panelshow.Controls.Add(tcl);
            tcl.Show();

        }

        private void ButTroGiup_Click(object sender, EventArgs e)
        {
            FormTroGiup tk = new FormTroGiup();
            panelshow.Show();
            panelshow.Controls.Clear();
            tk.TopLevel = false;
            tk.Dock = DockStyle.Fill;
            panelshow.Controls.Add(tk);
            tk.Show();
        }
    }
}
