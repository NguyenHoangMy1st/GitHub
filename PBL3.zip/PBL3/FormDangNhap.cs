﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FontAwesome.Sharp;
using Pbl3_new_.BLL;

namespace Pbl3_new_
{
    public partial class FormDangNhap : Form
    {
        public FormDangNhap()
        {
            InitializeComponent();
        }

        private void iconcerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void iconminimizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void iconhienthi_Click(object sender, EventArgs e)
        {
            if (txtpass.PasswordChar == '\0')
            {
                iconche.BringToFront();
                txtpass.PasswordChar = '●';
                iconhienthi.Visible = false;
                iconche.Visible = true;

            }
        }

        private void iconche_Click(object sender, EventArgs e)
        {
            if(txtpass.PasswordChar == '●')
             {
                iconhienthi.BringToFront();
                txtpass.PasswordChar = '\0';
                iconhienthi.Visible = true;
                iconche.Visible = false;

            }
        }

        private void buttonlogin_Click(object sender, EventArgs e)
        {
            foreach(NV n in BLLQLNV.Instance.GetALLNV())
            {
                if(txtuser.Text == n.TaiKhoan && txtpass.Text == n.MatKhau)
                {
                    if(n.ID_LoaiTK == 1)
                    {
                        MainForm f = new MainForm(n);
                        f.ShowDialog();
                    }
                    else
                    {
                        MainUserForm f = new MainUserForm(n);
                        f.ShowDialog();
                    }
                }
            }
            foreach(NV n in BLLQLNV.Instance.GetALLNV())
            {
                if(txtuser.Text != n.TaiKhoan || txtpass.Text != n.MatKhau)
                {
                    MessageBox.Show("Bạn đã nhập sai tài khoản hoặc mật khẩu", "Thông báo");
                    break;
                }
            }

        }
    }
}
