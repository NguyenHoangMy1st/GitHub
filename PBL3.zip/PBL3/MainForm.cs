﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FontAwesome.Sharp;

namespace Pbl3_new_
{
    public partial class MainForm : Form
    {
        private IconButton currentBtn;
        private Panel leftBorderBtn;
        private Form currentChildForm;
        NV nv = new NV();
        public MainForm(NV n)
        {
            leftBorderBtn = new Panel();
            leftBorderBtn.Size = new Size(7, 58);
       
            InitializeComponent();
            customizedesign();
            nv = n;
        }

        private void customizedesign()
        {
            panelQLTT.Visible = false;
            panelQLLLV.Visible = false;
        }
        private void hidesubmenu()
        {
            if (panelQLTT.Visible == true)
                panelQLTT.Visible = false;
            if (panelQLLLV.Visible == true)
                panelQLLLV.Visible = false;
        }
        private void showsubmenu(Panel Submenu)
        {
            if(Submenu.Visible == false)
            {
                hidesubmenu();
                Submenu.Visible = true;
            }    
            else
                Submenu.Visible = false;
        }


        

        private void iconcerrar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void iconmaximizar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            iconrestaurar.Visible = true;
            iconmaximizar.Visible = false;
        }

        private void iconrestaurar_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            iconrestaurar.Visible = false;
            iconmaximizar.Visible = true;
        }

        private void iconminimizar_Click(object sender, EventArgs e)
        {

            this.WindowState = FormWindowState.Minimized;

        }

        private void Butslide_Click(object sender, EventArgs e)
        {
            if (panelMenu.Width == 358)
            {
                panelMenu.Width = 70;
                ButQLLLV.Text = "";
                ButQLTT.Text = "";
                ButTTCN.Text = "";
                butTTNV.Text = "";
                ButXLLV.Text = "";
                ButTimKiem.Text = "";
                ButTinhLuong.Text = "";
                ButTroGiup.Text = "";
                Butdangxuat.Text = "";
            }
            else
            {
                panelMenu.Width = 358;
                ButQLLLV.Text = "Quản Lý Lịch Làm Việc";
                ButQLLLV.ForeColor = Color.White;
                ButQLTT.Text = "Quản Lý Thông Tin";
                ButQLTT.ForeColor = Color.White;
                ButTTCN.Text = "Thông Tin Cá Nhân";
                ButTTCN.ForeColor = Color.White;
                butTTNV.Text = "Thông Tin Nhân Viên";
                butTTNV.ForeColor = Color.White;
                ButXLLV.Text = "Xếp Lịch Làm Việc";
                ButXLLV.ForeColor = Color.White;
                ButTimKiem.Text = "Tìm Kiếm";
                ButTimKiem.ForeColor = Color.White;
                ButTinhLuong.Text = "Tính Lương";
                ButTinhLuong.ForeColor = Color.White;
                ButTroGiup.Text = "Báo Lỗi";
                ButTroGiup.ForeColor = Color.White;
                Butdangxuat.Text = "Đăng Xuất";
                Butdangxuat.ForeColor = Color.White;
            }
                

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString("HH:mm:ss");
            label2.Text = DateTime.Now.ToString("dd/ MM /yyy");
        }

        private void ButQLTT_Click(object sender, EventArgs e)
        {
            showsubmenu(panelQLTT);
        }

        private void ButQLLLV_Click_1(object sender, EventArgs e)
        {
            showsubmenu(panelQLLLV);
        }

        private void ButTTCN_Click(object sender, EventArgs e)
        {
            FormTTCN ttcn = new FormTTCN(nv);
            panelshow.Show();
            panelshow.Controls.Clear();
            ttcn.TopLevel = false;
            ttcn.Dock = DockStyle.Fill;
            panelshow.Controls.Add(ttcn);
            ttcn.Show();
        }

        private void Buthome_Click(object sender, EventArgs e)
        {
            panelshow.Controls.Clear();
            panelshow.Show();

        }

        private void butTTNV_Click(object sender, EventArgs e)
        {
            FormTTNV fc = new FormTTNV();
            panelshow.Show();
            panelshow.Controls.Clear();
            fc.TopLevel = false;
            fc.Dock = DockStyle.Fill;
            panelshow.Controls.Add(fc);
            fc.Show();
        }

        private void Butdangxuat_Click(object sender, EventArgs e)
        {
            
            DialogResult dlr = MessageBox.Show("Bạn muốn đăng xuất", "Thông báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dlr == DialogResult.Yes)
            {
               FormDangNhap f = new FormDangNhap();
                f.Show();
                this.Close();
            }
        }

        private void ButTinhLuong_Click(object sender, EventArgs e)
        {
            FormTinhLuong tl = new FormTinhLuong();
            panelshow.Show();
            panelshow.Controls.Clear();
            tl.TopLevel = false;
            tl.Dock = DockStyle.Fill;
            panelshow.Controls.Add(tl);
            tl.Show();

        }

        private void ButXLLV_Click(object sender, EventArgs e)
        {
            FormXLLV xllv = new FormXLLV();
            panelshow.Show();
            panelshow.Controls.Clear();
            xllv.TopLevel = false;
            xllv.Dock = DockStyle.Fill;
            panelshow.Controls.Add(xllv);
            xllv.Show();

        }

        private void ButTimKiem_Click(object sender, EventArgs e)
        {
            FormTimKiem_admin_ tk = new FormTimKiem_admin_();
            panelshow.Show();
            panelshow.Controls.Clear();
            tk.TopLevel = false;
            tk.Dock = DockStyle.Fill;
            panelshow.Controls.Add(tk);
            tk.Show();

        }

        private void ButTroGiup_Click(object sender, EventArgs e)
        {
            FormTroGiup tk = new FormTroGiup();
            panelshow.Show();
            panelshow.Controls.Clear();
            tk.TopLevel = false;
            tk.Dock = DockStyle.Fill;
            panelshow.Controls.Add(tk);
            tk.Show();
        }
    }
}
