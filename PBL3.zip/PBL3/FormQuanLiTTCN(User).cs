﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Pbl3_new_.BLL;
using Pbl3_new_.DTO;

namespace Pbl3_new_
{
    public partial class FormQuanLiTTCN_User_ : Form
    {
        NV nv = new NV();
        public FormQuanLiTTCN_User_(NV n)
        {
            InitializeComponent();
            nv = n;
            cbbCV.Items.AddRange(BLLQLNV.Instance.GetCbbChucVu().ToArray());
            GUI();
            
        }
        public void GUI()
        {
            txtMaNV.Enabled = false;
            txtMaNV.Text = nv.MaNV;
            txtName.Enabled = false;
            txtName.Text = nv.HoVaTen;
            txtCMND.Enabled = false;
            txtCMND.Text = nv.CMND;
            dateTimePicker1.Enabled = false;
            dateTimePicker1.Value = nv.NgaySinh;
            if (nv.GioiTinh == true)
            {
                radioButtonNam.Checked = true;
            }
            else
            {
                radioButtonNu.Checked = true;
            }
            txtQQ.Enabled = false;
            txtQQ.Text = nv.QueQuan;
            cbbCV.Enabled = false;
            int ID_ChucVu = Convert.ToInt32(nv.ID_ChucVu);
            foreach (CBBItem i in cbbCV.Items)
            {
                if (i.Value == nv.ID_ChucVu)
                {
                    cbbCV.SelectedItem = i;
                }
            }
            txtEmail.Enabled = false;
            txtEmail.Text = nv.Email;
            txtTKNH.Enabled = false;
            txtTKNH.Text = nv.TK_NganHang;
            txtSDT.Enabled = false;
            txtSDT.Text = nv.SDT;
           
        }

      

        public void Show(String MaNV)
        {
            NV n = BLLQLNV.Instance.GetNVByMaNV(MaNV);
            if (n == null)
            {
                txtMaNV.Text = nv.MaNV;
                txtName.Text = nv.HoVaTen;
                txtCMND.Text = nv.CMND;
                dateTimePicker1.Value = nv.NgaySinh;
                if (nv.GioiTinh == true)
                {
                    radioButtonNam.Checked = true;
                }
                else
                {
                    radioButtonNu.Checked = true;
                }
                txtQQ.Text = nv.QueQuan;
                foreach (CBBItem i in cbbCV.Items)
                {
                    if (i.Value == nv.ID_ChucVu)
                    {
                        cbbCV.SelectedItem = i;
                    }
                }
                txtEmail.Text = nv.Email;
                txtTKNH.Text = nv.TK_NganHang;
                txtSDT.Text = nv.SDT;
               
            }
        }


   

        private void bTThayDoiMatKhau_Click(object sender, EventArgs e)
        {
           FormThayDoiMatKhau_user_ f= new FormThayDoiMatKhau_user_(nv);
            f.ShowDialog();

        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {

            FormUpdateTTCN_User_ f = new FormUpdateTTCN_User_(nv);
            f.d = new FormUpdateTTCN_User_.MyDel(Show);
            f.ShowDialog();
        }
    }
}
    

