﻿namespace Pbl3_new_
{
    partial class MainUserForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainUserForm));
            this.panel2 = new System.Windows.Forms.Panel();
            this.iconrestaurar = new System.Windows.Forms.PictureBox();
            this.iconmaximizar = new System.Windows.Forms.PictureBox();
            this.iconminimizar = new System.Windows.Forms.PictureBox();
            this.iconcerrar = new System.Windows.Forms.PictureBox();
            this.Butslide = new FontAwesome.Sharp.IconButton();
            this.Buthome = new FontAwesome.Sharp.IconButton();
            this.panelMenu = new System.Windows.Forms.Panel();
            this.ButTroGiup = new System.Windows.Forms.Button();
            this.ButTraCuuLuong = new System.Windows.Forms.Button();
            this.panelQLLLV = new System.Windows.Forms.Panel();
            this.ButDKLB = new System.Windows.Forms.Button();
            this.ButDD = new System.Windows.Forms.Button();
            this.ButXLLV = new System.Windows.Forms.Button();
            this.ButQLLLV = new System.Windows.Forms.Button();
            this.ButQLTTCN = new System.Windows.Forms.Button();
            this.Butdangxuat = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panelshow = new System.Windows.Forms.Panel();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconrestaurar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconmaximizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconminimizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconcerrar)).BeginInit();
            this.panelMenu.SuspendLayout();
            this.panelQLLLV.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(92)))), ((int)(((byte)(138)))));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.iconrestaurar);
            this.panel2.Controls.Add(this.iconmaximizar);
            this.panel2.Controls.Add(this.iconminimizar);
            this.panel2.Controls.Add(this.iconcerrar);
            this.panel2.Controls.Add(this.Butslide);
            this.panel2.Controls.Add(this.Buthome);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(358, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1096, 50);
            this.panel2.TabIndex = 1;
            // 
            // iconrestaurar
            // 
            this.iconrestaurar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.iconrestaurar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconrestaurar.Image = ((System.Drawing.Image)(resources.GetObject("iconrestaurar.Image")));
            this.iconrestaurar.Location = new System.Drawing.Point(1008, 5);
            this.iconrestaurar.Name = "iconrestaurar";
            this.iconrestaurar.Size = new System.Drawing.Size(38, 37);
            this.iconrestaurar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.iconrestaurar.TabIndex = 5;
            this.iconrestaurar.TabStop = false;
            this.iconrestaurar.Click += new System.EventHandler(this.iconrestaurar_Click);
            // 
            // iconmaximizar
            // 
            this.iconmaximizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.iconmaximizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconmaximizar.Image = ((System.Drawing.Image)(resources.GetObject("iconmaximizar.Image")));
            this.iconmaximizar.Location = new System.Drawing.Point(1001, 3);
            this.iconmaximizar.Name = "iconmaximizar";
            this.iconmaximizar.Size = new System.Drawing.Size(45, 39);
            this.iconmaximizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.iconmaximizar.TabIndex = 4;
            this.iconmaximizar.TabStop = false;
            this.iconmaximizar.Click += new System.EventHandler(this.iconmaximizar_Click);
            // 
            // iconminimizar
            // 
            this.iconminimizar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.iconminimizar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconminimizar.Image = ((System.Drawing.Image)(resources.GetObject("iconminimizar.Image")));
            this.iconminimizar.Location = new System.Drawing.Point(954, 2);
            this.iconminimizar.Name = "iconminimizar";
            this.iconminimizar.Size = new System.Drawing.Size(48, 39);
            this.iconminimizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.iconminimizar.TabIndex = 2;
            this.iconminimizar.TabStop = false;
            this.iconminimizar.Click += new System.EventHandler(this.iconminimizar_Click);
            // 
            // iconcerrar
            // 
            this.iconcerrar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.iconcerrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconcerrar.Image = ((System.Drawing.Image)(resources.GetObject("iconcerrar.Image")));
            this.iconcerrar.Location = new System.Drawing.Point(1052, 2);
            this.iconcerrar.Name = "iconcerrar";
            this.iconcerrar.Size = new System.Drawing.Size(39, 37);
            this.iconcerrar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.iconcerrar.TabIndex = 1;
            this.iconcerrar.TabStop = false;
            this.iconcerrar.Click += new System.EventHandler(this.iconcerrar_Click);
            // 
            // Butslide
            // 
            this.Butslide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Butslide.IconChar = FontAwesome.Sharp.IconChar.Bars;
            this.Butslide.IconColor = System.Drawing.Color.White;
            this.Butslide.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Butslide.IconSize = 35;
            this.Butslide.Location = new System.Drawing.Point(0, 2);
            this.Butslide.Name = "Butslide";
            this.Butslide.Size = new System.Drawing.Size(75, 47);
            this.Butslide.TabIndex = 0;
            this.Butslide.UseVisualStyleBackColor = true;
            this.Butslide.Click += new System.EventHandler(this.Butslide_Click);
            // 
            // Buthome
            // 
            this.Buthome.BackColor = System.Drawing.Color.Transparent;
            this.Buthome.FlatAppearance.BorderSize = 0;
            this.Buthome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Buthome.IconChar = FontAwesome.Sharp.IconChar.Home;
            this.Buthome.IconColor = System.Drawing.Color.White;
            this.Buthome.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Buthome.Location = new System.Drawing.Point(72, 0);
            this.Buthome.Name = "Buthome";
            this.Buthome.Size = new System.Drawing.Size(65, 52);
            this.Buthome.TabIndex = 0;
            this.Buthome.UseVisualStyleBackColor = false;
            this.Buthome.Click += new System.EventHandler(this.Buthome_Click);
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(5)))), ((int)(((byte)(39)))), ((int)(((byte)(68)))));
            this.panelMenu.Controls.Add(this.ButTroGiup);
            this.panelMenu.Controls.Add(this.ButTraCuuLuong);
            this.panelMenu.Controls.Add(this.panelQLLLV);
            this.panelMenu.Controls.Add(this.ButQLLLV);
            this.panelMenu.Controls.Add(this.ButQLTTCN);
            this.panelMenu.Controls.Add(this.Butdangxuat);
            this.panelMenu.Controls.Add(this.panel4);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(358, 795);
            this.panelMenu.TabIndex = 0;
            // 
            // ButTroGiup
            // 
            this.ButTroGiup.AllowDrop = true;
            this.ButTroGiup.AutoSize = true;
            this.ButTroGiup.Dock = System.Windows.Forms.DockStyle.Top;
            this.ButTroGiup.FlatAppearance.BorderSize = 0;
            this.ButTroGiup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButTroGiup.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButTroGiup.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ButTroGiup.Image = ((System.Drawing.Image)(resources.GetObject("ButTroGiup.Image")));
            this.ButTroGiup.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButTroGiup.Location = new System.Drawing.Point(0, 520);
            this.ButTroGiup.Name = "ButTroGiup";
            this.ButTroGiup.Size = new System.Drawing.Size(358, 56);
            this.ButTroGiup.TabIndex = 21;
            this.ButTroGiup.Text = "Trợ Giúp";
            this.ButTroGiup.UseVisualStyleBackColor = true;
            this.ButTroGiup.Click += new System.EventHandler(this.ButTroGiup_Click);
            // 
            // ButTraCuuLuong
            // 
            this.ButTraCuuLuong.AllowDrop = true;
            this.ButTraCuuLuong.AutoSize = true;
            this.ButTraCuuLuong.Dock = System.Windows.Forms.DockStyle.Top;
            this.ButTraCuuLuong.FlatAppearance.BorderSize = 0;
            this.ButTraCuuLuong.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButTraCuuLuong.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButTraCuuLuong.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ButTraCuuLuong.Image = ((System.Drawing.Image)(resources.GetObject("ButTraCuuLuong.Image")));
            this.ButTraCuuLuong.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButTraCuuLuong.Location = new System.Drawing.Point(0, 464);
            this.ButTraCuuLuong.Name = "ButTraCuuLuong";
            this.ButTraCuuLuong.Size = new System.Drawing.Size(358, 56);
            this.ButTraCuuLuong.TabIndex = 20;
            this.ButTraCuuLuong.Text = "Tra Cứu Lương";
            this.ButTraCuuLuong.UseVisualStyleBackColor = true;
            this.ButTraCuuLuong.Click += new System.EventHandler(this.ButTraCuuLuong_Click);
            // 
            // panelQLLLV
            // 
            this.panelQLLLV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(169)))), ((int)(((byte)(183)))));
            this.panelQLLLV.Controls.Add(this.ButDKLB);
            this.panelQLLLV.Controls.Add(this.ButDD);
            this.panelQLLLV.Controls.Add(this.ButXLLV);
            this.panelQLLLV.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelQLLLV.Location = new System.Drawing.Point(0, 287);
            this.panelQLLLV.Name = "panelQLLLV";
            this.panelQLLLV.Size = new System.Drawing.Size(358, 177);
            this.panelQLLLV.TabIndex = 17;
            // 
            // ButDKLB
            // 
            this.ButDKLB.Dock = System.Windows.Forms.DockStyle.Top;
            this.ButDKLB.FlatAppearance.BorderSize = 0;
            this.ButDKLB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButDKLB.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButDKLB.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ButDKLB.Image = ((System.Drawing.Image)(resources.GetObject("ButDKLB.Image")));
            this.ButDKLB.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButDKLB.Location = new System.Drawing.Point(0, 119);
            this.ButDKLB.Name = "ButDKLB";
            this.ButDKLB.Size = new System.Drawing.Size(358, 52);
            this.ButDKLB.TabIndex = 2;
            this.ButDKLB.Text = "Đăng Kí Lịch Bận";
            this.ButDKLB.UseVisualStyleBackColor = true;
            this.ButDKLB.Click += new System.EventHandler(this.ButDKLB_Click);
            // 
            // ButDD
            // 
            this.ButDD.Dock = System.Windows.Forms.DockStyle.Top;
            this.ButDD.FlatAppearance.BorderSize = 0;
            this.ButDD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButDD.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButDD.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ButDD.Image = ((System.Drawing.Image)(resources.GetObject("ButDD.Image")));
            this.ButDD.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButDD.Location = new System.Drawing.Point(0, 62);
            this.ButDD.Name = "ButDD";
            this.ButDD.Size = new System.Drawing.Size(358, 57);
            this.ButDD.TabIndex = 1;
            this.ButDD.Text = " Điểm Danh";
            this.ButDD.UseVisualStyleBackColor = true;
            this.ButDD.Click += new System.EventHandler(this.ButDD_Click);
            // 
            // ButXLLV
            // 
            this.ButXLLV.Dock = System.Windows.Forms.DockStyle.Top;
            this.ButXLLV.FlatAppearance.BorderSize = 0;
            this.ButXLLV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButXLLV.Font = new System.Drawing.Font("Century Gothic", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButXLLV.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ButXLLV.Image = ((System.Drawing.Image)(resources.GetObject("ButXLLV.Image")));
            this.ButXLLV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButXLLV.Location = new System.Drawing.Point(0, 0);
            this.ButXLLV.Name = "ButXLLV";
            this.ButXLLV.Size = new System.Drawing.Size(358, 62);
            this.ButXLLV.TabIndex = 0;
            this.ButXLLV.Text = "Xem Lịch Làm Việc";
            this.ButXLLV.UseVisualStyleBackColor = true;
            this.ButXLLV.Click += new System.EventHandler(this.ButXLLV_Click);
            // 
            // ButQLLLV
            // 
            this.ButQLLLV.AllowDrop = true;
            this.ButQLLLV.AutoSize = true;
            this.ButQLLLV.Dock = System.Windows.Forms.DockStyle.Top;
            this.ButQLLLV.FlatAppearance.BorderSize = 0;
            this.ButQLLLV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButQLLLV.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButQLLLV.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ButQLLLV.Image = ((System.Drawing.Image)(resources.GetObject("ButQLLLV.Image")));
            this.ButQLLLV.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButQLLLV.Location = new System.Drawing.Point(0, 231);
            this.ButQLLLV.Name = "ButQLLLV";
            this.ButQLLLV.Size = new System.Drawing.Size(358, 56);
            this.ButQLLLV.TabIndex = 16;
            this.ButQLLLV.Text = "Quản Lý Lịch Làm Việc";
            this.ButQLLLV.UseVisualStyleBackColor = true;
            this.ButQLLLV.Click += new System.EventHandler(this.ButQLLLV_Click);
            // 
            // ButQLTTCN
            // 
            this.ButQLTTCN.AllowDrop = true;
            this.ButQLTTCN.AutoSize = true;
            this.ButQLTTCN.Dock = System.Windows.Forms.DockStyle.Top;
            this.ButQLTTCN.FlatAppearance.BorderColor = System.Drawing.Color.NavajoWhite;
            this.ButQLTTCN.FlatAppearance.BorderSize = 0;
            this.ButQLTTCN.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.ButQLTTCN.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ButQLTTCN.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ButQLTTCN.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ButQLTTCN.Image = ((System.Drawing.Image)(resources.GetObject("ButQLTTCN.Image")));
            this.ButQLTTCN.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ButQLTTCN.Location = new System.Drawing.Point(0, 175);
            this.ButQLTTCN.Name = "ButQLTTCN";
            this.ButQLTTCN.Size = new System.Drawing.Size(358, 56);
            this.ButQLTTCN.TabIndex = 12;
            this.ButQLTTCN.Text = "Quản Lý Thông Tin ";
            this.ButQLTTCN.UseVisualStyleBackColor = true;
            this.ButQLTTCN.Click += new System.EventHandler(this.ButQLTTCN_Click_1);
            // 
            // Butdangxuat
            // 
            this.Butdangxuat.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Butdangxuat.FlatAppearance.BorderSize = 0;
            this.Butdangxuat.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Butdangxuat.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Butdangxuat.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Butdangxuat.Image = ((System.Drawing.Image)(resources.GetObject("Butdangxuat.Image")));
            this.Butdangxuat.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Butdangxuat.Location = new System.Drawing.Point(0, 744);
            this.Butdangxuat.Name = "Butdangxuat";
            this.Butdangxuat.Size = new System.Drawing.Size(358, 51);
            this.Butdangxuat.TabIndex = 13;
            this.Butdangxuat.Text = "Đăng Xuất";
            this.Butdangxuat.UseVisualStyleBackColor = true;
            this.Butdangxuat.Click += new System.EventHandler(this.Butdangxuat_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(92)))), ((int)(((byte)(138)))));
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(358, 175);
            this.panel4.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(56, -5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(229, 192);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoEllipsis = true;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(739, 6);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(99, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(936, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 26);
            this.label2.TabIndex = 1;
            this.label2.Text = "label2";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(673, 6);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(60, 35);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(92)))), ((int)(((byte)(138)))));
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(358, 749);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1096, 46);
            this.panel1.TabIndex = 3;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(888, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(42, 41);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // panelshow
            // 
            this.panelshow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(207)))), ((int)(((byte)(226)))), ((int)(((byte)(231)))));
            this.panelshow.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelshow.BackgroundImage")));
            this.panelshow.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelshow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelshow.Location = new System.Drawing.Point(358, 50);
            this.panelshow.Name = "panelshow";
            this.panelshow.Size = new System.Drawing.Size(1096, 699);
            this.panelshow.TabIndex = 4;
            // 
            // MainUserForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1454, 795);
            this.Controls.Add(this.panelshow);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panelMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainUserForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.iconrestaurar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconmaximizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconminimizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.iconcerrar)).EndInit();
            this.panelMenu.ResumeLayout(false);
            this.panelMenu.PerformLayout();
            this.panelQLLLV.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel2;
        private FontAwesome.Sharp.IconButton Buthome;
        private System.Windows.Forms.Panel panelMenu;
        private FontAwesome.Sharp.IconButton Butslide;
        private System.Windows.Forms.PictureBox iconrestaurar;
        private System.Windows.Forms.PictureBox iconmaximizar;
        private System.Windows.Forms.PictureBox iconminimizar;
        private System.Windows.Forms.PictureBox iconcerrar;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button Butdangxuat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panelshow;
        private System.Windows.Forms.Button ButQLTTCN;
        private System.Windows.Forms.Button ButTraCuuLuong;
        private System.Windows.Forms.Panel panelQLLLV;
        private System.Windows.Forms.Button ButDKLB;
        private System.Windows.Forms.Button ButDD;
        private System.Windows.Forms.Button ButXLLV;
        private System.Windows.Forms.Button ButQLLLV;
        private System.Windows.Forms.Button ButTroGiup;
    }
}