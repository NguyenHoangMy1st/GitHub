﻿namespace Pbl3_new_
{
    partial class FormTimKiem_admin_
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormTimKiem_admin_));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.rdbtnMaNV = new System.Windows.Forms.RadioButton();
            this.rdbtnCMND = new System.Windows.Forms.RadioButton();
            this.rdbtnName = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(235)))), ((int)(((byte)(232)))));
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(215)))), ((int)(((byte)(235)))), ((int)(((byte)(232)))));
            this.dataGridView1.Location = new System.Drawing.Point(60, 158);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(836, 254);
            this.dataGridView1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(393, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 23);
            this.label1.TabIndex = 1;
            this.label1.Text = "TÌM KIẾM";
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnSearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSearch.BackgroundImage")));
            this.btnSearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSearch.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSearch.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSearch.Location = new System.Drawing.Point(792, 74);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(52, 38);
            this.btnSearch.TabIndex = 5;
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.buttonsearch_Click);
            // 
            // txtSearch
            // 
            this.txtSearch.Location = new System.Drawing.Point(291, 83);
            this.txtSearch.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(496, 22);
            this.txtSearch.TabIndex = 7;
            // 
            // rdbtnMaNV
            // 
            this.rdbtnMaNV.AutoSize = true;
            this.rdbtnMaNV.BackColor = System.Drawing.Color.Transparent;
            this.rdbtnMaNV.ForeColor = System.Drawing.Color.Transparent;
            this.rdbtnMaNV.Location = new System.Drawing.Point(291, 122);
            this.rdbtnMaNV.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdbtnMaNV.Name = "rdbtnMaNV";
            this.rdbtnMaNV.Size = new System.Drawing.Size(124, 20);
            this.rdbtnMaNV.TabIndex = 8;
            this.rdbtnMaNV.TabStop = true;
            this.rdbtnMaNV.Text = "MÃ NHÂN VIÊN";
            this.rdbtnMaNV.UseVisualStyleBackColor = false;
            // 
            // rdbtnCMND
            // 
            this.rdbtnCMND.AutoSize = true;
            this.rdbtnCMND.BackColor = System.Drawing.Color.Transparent;
            this.rdbtnCMND.ForeColor = System.Drawing.Color.Transparent;
            this.rdbtnCMND.Location = new System.Drawing.Point(728, 122);
            this.rdbtnCMND.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdbtnCMND.Name = "rdbtnCMND";
            this.rdbtnCMND.Size = new System.Drawing.Size(109, 20);
            this.rdbtnCMND.TabIndex = 10;
            this.rdbtnCMND.TabStop = true;
            this.rdbtnCMND.Text = "CMND/CCCD";
            this.rdbtnCMND.UseVisualStyleBackColor = false;
            // 
            // rdbtnName
            // 
            this.rdbtnName.AutoSize = true;
            this.rdbtnName.BackColor = System.Drawing.Color.Transparent;
            this.rdbtnName.ForeColor = System.Drawing.Color.Transparent;
            this.rdbtnName.Location = new System.Drawing.Point(501, 122);
            this.rdbtnName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rdbtnName.Name = "rdbtnName";
            this.rdbtnName.Size = new System.Drawing.Size(132, 20);
            this.rdbtnName.TabIndex = 9;
            this.rdbtnName.TabStop = true;
            this.rdbtnName.Text = "TÊN NHÂN VIÊN";
            this.rdbtnName.UseVisualStyleBackColor = false;
            // 
            // FormTimKiem_admin_
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(955, 514);
            this.Controls.Add(this.rdbtnName);
            this.Controls.Add(this.rdbtnCMND);
            this.Controls.Add(this.rdbtnMaNV);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "FormTimKiem_admin_";
            this.Text = "FormTTNV";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.RadioButton rdbtnMaNV;
        private System.Windows.Forms.RadioButton rdbtnCMND;
        private System.Windows.Forms.RadioButton rdbtnName;
    }
}